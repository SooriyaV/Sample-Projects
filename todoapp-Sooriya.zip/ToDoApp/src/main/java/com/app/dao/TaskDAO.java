package com.app.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.entity.TaskEntity;
import com.app.repository.TaskRepository;

@Component
public class TaskDAO {

@Autowired
private TaskRepository taskRepo;

private TaskEntity task;

public List<TaskEntity> getAllTasks() {
	return taskRepo.findAll();
}

public List<TaskEntity> createOrUpdate(TaskEntity task) {
		taskRepo.save(task);
		return taskRepo.findAll();	
}

public List<TaskEntity> removeTask(TaskEntity task) {
	taskRepo.delete(task);
	return taskRepo.findAll();
}

}
