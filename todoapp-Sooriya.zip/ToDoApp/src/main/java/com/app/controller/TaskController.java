package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.TaskDAO;
import com.app.entity.TaskEntity;

@RestController
@RequestMapping({"/task"})
public class TaskController {
	
	@Autowired
	private TaskDAO taskdao;
	
	@RequestMapping(value= {"/allTasks"}, method={org.springframework.web.bind.annotation.RequestMethod.GET}, produces={"application/json"})
	public List<TaskEntity> getAllTasks() {
		return taskdao.getAllTasks();
	}
	
	@RequestMapping(value= {"/update"}, method={org.springframework.web.bind.annotation.RequestMethod.POST}, consumes={"application/json"})
	public List<TaskEntity> manipulateTasks(@RequestBody TaskEntity task) {
		return taskdao.createOrUpdate(task);
	}
	
	@RequestMapping(value= {"/delete"}, method={org.springframework.web.bind.annotation.RequestMethod.POST}, consumes={"application/json"})
	public List<TaskEntity> deleteTasks(@RequestBody TaskEntity task) {
		return taskdao.removeTask(task);
	}

}
