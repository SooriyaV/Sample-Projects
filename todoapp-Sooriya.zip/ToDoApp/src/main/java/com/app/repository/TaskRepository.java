package com.app.repository;

import org.springframework.stereotype.Repository;

import com.app.entity.TaskEntity;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public abstract interface TaskRepository extends JpaRepository<TaskEntity, String> {

}
