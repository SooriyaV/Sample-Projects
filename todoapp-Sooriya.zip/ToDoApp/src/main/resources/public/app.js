/**
 * 
 */
let app = angular.module('toDoApp',['ngRoute']);

app.config( ($routeProvider) => {
	$routeProvider
	.when('/', {
		templateUrl : 'pages/tasks.html'
	})
})