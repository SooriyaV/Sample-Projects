/**
 * 
 */
app.controller('taskController', ['$scope', 'taskService', function ($scope, taskService) {
	let vm = this;
	vm.pendingTasks = [];
	vm.completedTasks = [];
	vm.current = "";
	vm.open = true;
	taskService.getAllTasks().then ((response) => {
		_load(response);
	});
	
	function _load(response) {
		vm.newTask = {
				'title' : '',
				'description': '',
				'status': 'PENDING'			
		};
		vm.pendingTasks = _.filter(response.data, {'status': 'PENDING'});
		vm.completedTasks = _.filter(response.data, {'status': 'COMPLETED'});
	}
	
	vm.expand = function (task) {
		vm.open = (vm.current == task.id) ? !vm.open : true;
		vm.current = task.id;
	}
	
	vm.remove = function (task) {
		taskService.removeTask(task).then((response) => {
			//vm.open = false;
			_load(response);			
		});
	}
	
	vm.addTask = function (task) {
		taskService.createOrUpdateTask(task).then((response) => {
			_load(response);			
		});
	}
	
	vm.completeTask = function (task) {
		_.set(task, 'status', 'COMPLETED');
		taskService.createOrUpdateTask(task).then((response) => {
			vm.open = false;
			_load(response);			
		});
	}
	
	
}]);