/**
 * 
 */
app.factory('taskService', ($http) => {
	
	let config ={
            headers : {
                'Content-Type': 'application/json'
            }
        };
	
	function getAllTasks () {
		return $http.get('/task/allTasks');		
	}
	
	function createOrUpdateTask (task) {
		return $http.post('/task/update', task, config);
	}
	
	function removeTask (task) {
		return $http.post('/task/delete', task, config);		
	}
	
	return {
		getAllTasks : getAllTasks,
		createOrUpdateTask: createOrUpdateTask,
		removeTask: removeTask
		}
});